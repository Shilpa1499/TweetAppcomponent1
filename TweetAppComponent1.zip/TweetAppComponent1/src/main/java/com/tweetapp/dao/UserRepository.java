package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;

import com.tweetapp.model.UserModel;

public class UserRepository {
	Connection conn=JDBCConnection.getConnection();
	
	public boolean addUser(UserModel user) throws SQLException {
		if(conn!=null) {
			try {
				String query="Insert into userdetails(firstName,lastName,email,gender,password,dob) values (?,?,?,?,?,?)";
				PreparedStatement stmt= conn.prepareStatement(query);
				stmt.setString(1, user.getFirstName());
				stmt.setString(2, user.getLastName());
				stmt.setString(3, user.getEmail());
				stmt.setString(4, user.getGender());
				stmt.setString(5, user.getPassword());
				stmt.setDate(6, user.getDob());
				stmt.execute();
				return true;
			}
			catch(Exception ex) {
				return false;
			}
		}
		return false;
	}
	
	public UserModel findbyId(String username) {
		UserModel user=null;
		if(conn!=null) {
			try {
			
				String query="Select * from userdetails where email=?;";
				PreparedStatement stmt=conn.prepareStatement(query);
				stmt.setString(1, username);
				ResultSet quser=stmt.executeQuery();
				if(quser.next()) {
				user=new UserModel(quser.getString("firstName"),quser.getString("lastName"),
						quser.getString("email"),quser.getString("gender"),quser.getString("password"),quser.getDate("dob"));
				}
				return user;
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println(e);
				return user;
			}
		}
		return user;
	}
	public List<UserModel> findAll(){
		List<UserModel> users=new ArrayList<>();
		if(conn!=null) {
			try {
				Statement stmt=conn.createStatement();
				String query="Select * from userdetails;";
				ResultSet quser=stmt.executeQuery(query);
				while(quser.next()) {
					UserModel user=new UserModel(quser.getString("firstname"),quser.getString("lastname"),
							quser.getString("email"),quser.getString("gender"),quser.getString("password"),quser.getDate("dob"));
				users.add(user);
				}
				return users;
				
			} catch (SQLException e) {
				e.printStackTrace();
				return users;
			}
		}
		return users;
	}
	
	public boolean updatePassword(UserModel user, String newPassword) {
		if(conn!=null) {
		try {
		String query="update userdetails set password=? where email=?";
		PreparedStatement stmt=conn.prepareStatement(query);
		stmt.setString(1, newPassword);
		stmt.setString(2, user.getEmail());
		System.out.println("Updated status");
		stmt.execute();
		return true;
		} catch (SQLException e) {
		System.out.println("unable to update status");
		return false;
		}

		}
		System.out.println("unable to update status");
		return false;
		}
}
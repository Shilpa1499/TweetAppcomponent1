package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.tweetapp.model.TweetModel;

public class TweetRepository {
	Connection con=JDBCConnection.getConnection();
	public boolean postTweet(TweetModel tweet) throws SQLException {
		if(con!=null) {

				String query="insert into tweetdetails(userName,tweet) values (?,?)";
				PreparedStatement stmt=con.prepareStatement(query);
				stmt.setString(1, tweet.getUserId());
				stmt.setString(2, tweet.getTweet());
				return stmt.execute();
		}
		return false;
	}
	public List<TweetModel> findAll(){
		List<TweetModel> tweets=new ArrayList<>();
		if(con!=null) {
			try {
				Statement stmt=con.createStatement();
				String query="select * from tweetdetails";
				ResultSet rs=stmt.executeQuery(query);
				while(rs.next()) {
					TweetModel tweet=new TweetModel(rs.getString("tweet"),rs.getString("userName"));
					tweets.add(tweet);
				}
				return tweets;
			}
			catch(Exception e) {
				return tweets;
			}
		}
		return tweets;
	}

}

package com.tweetapp.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JDBCConnection {
	public static Connection getConnection() {
		Properties p=new Properties();
		try {
			FileInputStream reader=new FileInputStream(new File("C:\\Users\\894463\\Downloads\\tweetapp\\TweetAppComponent1\\db.properties"));
			p.load(reader);
			Class.forName(p.getProperty("jdbc.driver"));
		}catch(ClassNotFoundException e) {
			System.out.println("Not able to find jdbc driver please make sure of adding it");
		}catch(FileNotFoundException e) {
			System.out.println("Not able to find db.properties file");
		}catch(IOException e) {
			System.out.println("Not able to find db.properties file");
			return null;
		}
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+p.getProperty("database"),p.getProperty("jdbc.username"),p.getProperty("jdbc.password"));
			if(con!=null) {
				return con;
			}
			else {
				System.out.println("Connection Failed");
				return null;
			}
			}catch(SQLException e) {
				System.out.println("MySQL Connection Failed");
				e.printStackTrace();
				return null;
			}
	}
}
		


package com.tweetapp.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import com.tweetapp.dao.UserRepository;
import com.tweetapp.exception.PasswordMismatchException;
import com.tweetapp.exception.UserExistsException;
import com.tweetapp.exception.UserNotFoundException;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.UserService;
public class UserServiceImpl implements UserService {
	
    UserRepository userRepo=new UserRepository();

    @Override
    public String register(UserModel userDetails) {
        System.out.println("Added user ");
        try {
        	UserModel user=userRepo.findbyId(userDetails.getEmail());
            if(user==null) {
                userRepo.addUser(userDetails);
                return "Registration successful,You can login";
            }
            throw new UserExistsException("User already registered, Login Now");
        }
        catch (Exception e){
            return e.getMessage();
        }

    }

    @Override
    public boolean login(String username, String password) {
        System.out.println("login user ");
        try {
        	UserModel user = userRepo.findbyId(username);
            if (user==null) {
                throw new UserNotFoundException("Username Not Found, Register");
            }
            if(user.getEmail().equalsIgnoreCase(username) &&
                user.getPassword().equals(password)){
                System.out.println("Login Successful");
                return true;
            }
            System.out.println("Password is not correct ,Retry again");
            return false;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }

    }

    @Override
    public List<String> viewAllUsers() {
        System.out.println("user service to get all the users");
        return userRepo.findAll().stream().map(o->o.getEmail()).collect(Collectors.toList());
    }



    @Override
    public boolean resetPassword(String username, String oldPassword, String newPassword) {
    System.out.println("service for reset user password");
    try {
    UserModel user = userRepo.findbyId(username);
    if (user==null) {
    throw new UserNotFoundException("Username Not Found, Register");
    }
    if(user.getPassword().equals(oldPassword)) {
    user.setPassword(newPassword);
    userRepo.updatePassword(user,newPassword);
    System.out.println("Password reset Successful ,Login again");
    return true;
    }
    throw new PasswordMismatchException("Old password and new Password Not Matched");
    }
    catch (Exception e){
    System.out.println(e.getMessage());
    return false;
    }



    }
    @Override
    public boolean logout(String username) {
        System.out.println("In service for logout user ");
        try {
            UserModel user = userRepo.findbyId(username);
            if (user==null) {
                throw new UserNotFoundException("Username Not Found, Register");
            }
            System.out.println("Logout Successful");
            return true;

        }
        catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }
    }
    

    
    @Override
    public boolean forgetPassword(String username,String newPassword) {

    try {
    UserModel user = userRepo.findbyId(username);
    if (user==null) {
    throw new UserNotFoundException("Username Not Found, Register");
    }

    boolean result= userRepo.updatePassword(user,newPassword);
    if(result)
    System.out.println("Password Reset Successful");
    else
    System.out.println("Password reset unsuccessful");
    return true;
    }catch (UserNotFoundException e1) {
    System.out.println(e1.getMessage());
    return false;
    }
    }
}

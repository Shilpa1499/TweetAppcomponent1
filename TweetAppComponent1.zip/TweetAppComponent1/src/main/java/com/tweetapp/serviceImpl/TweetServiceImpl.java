package com.tweetapp.serviceImpl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.tweetapp.dao.TweetRepository;
import com.tweetapp.dao.UserRepository;
import com.tweetapp.exception.PasswordMismatchException;
import com.tweetapp.exception.UserNotFoundException;
import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.TweetService;
public class TweetServiceImpl implements TweetService {
TweetRepository tweetRepo=new TweetRepository();

@Override
public String postATweet(TweetModel tweet) {
    try{
        tweetRepo.postTweet(tweet);
        return "Tweet added Successfully";
    }
    catch (Exception ex){
        System.out.println("Failed to add tweet");
        return ex.getMessage();
    }

}


@Override
public List<String> viewTweetByUser(String username) {
	System.out.println("Displaying tweets added by you");
	
    return tweetRepo.findAll().stream().filter(tweet->tweet.getUserId().equals(username))
            .map(TweetModel::getTweet)
            .collect(Collectors.toList());
}
@Override
public Map<String,List<String>> viewTweetByAllUser(){
	System.out.println("Displaying users tweets");
	return tweetRepo.findAll().stream().collect(Collectors.groupingBy(TweetModel::getUserId,
			Collectors.mapping(TweetModel::getTweet, 
					Collectors.toList())));
}


}

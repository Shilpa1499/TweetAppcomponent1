package com.tweetapp.service;

import java.util.List;
import java.util.Map;

import com.tweetapp.model.TweetModel;



public interface TweetService {
    String postATweet(TweetModel tweet);
    List<String> viewTweetByUser(String username);
	Map<String, List<String>> viewTweetByAllUser();
}

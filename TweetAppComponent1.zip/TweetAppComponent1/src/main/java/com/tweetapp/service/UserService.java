package com.tweetapp.service;

import java.util.List;

import com.tweetapp.model.UserModel;

public interface UserService {
	String register(UserModel userDetails);
    boolean login(String username,String password);
    boolean logout(String username);
    List<String> viewAllUsers();
    boolean resetPassword(String username,String old,String newPassword);
	boolean forgetPassword(String username, String newPassword);
}

package com.tweetapp.model;

public class TweetModel {

	private String tweet;
	private String userId;
	
	public TweetModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TweetModel(String tweet, String userId) {
		super();
		this.tweet = tweet;
		this.userId = userId;
	}

	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	
}
